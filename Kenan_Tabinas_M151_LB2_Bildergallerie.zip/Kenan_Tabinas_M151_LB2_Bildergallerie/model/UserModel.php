<?php
/**
 * Created by PhpStorm.
 * UserView: Keahnignen
 * Date: 18/11/2017
 * Time: 20:17
 */

class UserModel
{

    /**
     * @var int
     */
    public $id;

    /**
     * @var string
     */
    public $username;

    /**
     * @var string
     */

    public $email;

    /**
     * @var string
     */

    public $password;

    /**
     * @var bool
     */
    public $isAdmin;


}