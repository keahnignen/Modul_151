<?php
/**
 * Created by PhpStorm.
 * User: vmadmin
 * Date: 01.03.2018
 * Time: 15:05
 */


class Post {



}