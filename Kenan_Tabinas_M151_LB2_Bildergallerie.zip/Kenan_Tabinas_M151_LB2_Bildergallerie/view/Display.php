<?php




/**
 * Created by PhpStorm.
 * User: vmadmin
 * Date: 01.03.2018
 * Time: 14:53
 */

class Display
{

    public static $area;
    public static $post;

}