<?php
  session_destroy();
  header("Location: index.php?function=login");
  exit;
?>
