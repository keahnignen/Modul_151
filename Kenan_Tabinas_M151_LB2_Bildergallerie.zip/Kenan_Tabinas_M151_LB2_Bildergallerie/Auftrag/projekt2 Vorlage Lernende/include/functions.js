function confirmDelete() {
  return confirm("Soll dieser Beitrag gelöscht werden?");
}
